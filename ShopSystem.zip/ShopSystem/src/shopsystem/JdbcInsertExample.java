/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package shopsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcInsertExample {
    String url = "jdbc:mysql://localhost:3306/ShopSystem"; // Replace with your MySQL database URL
        String username = "root"; // Replace with your MySQL username
        String password = "Amratku!1"; // Replace with your MySQL password
 public void insertPizza(String str){
     
     String insertQuery1 = str; 
  
   
        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement()) {

            // Execute the query
            int rowsInserted = statement.executeUpdate(insertQuery1);
            if (rowsInserted > 0) {
                System.out.println("Data inserted successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
     public void deleterow(String str){
     String insertQuery1 =  str; 
   
        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement()) {

            // Execute the query
            int rowsInserted = statement.executeUpdate(insertQuery1);
            if (rowsInserted > 0) {
                System.out.println("Data inserted successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }   
    public static void main(String[] args) {
        
        
        // SQL query to insert data
     
}
}