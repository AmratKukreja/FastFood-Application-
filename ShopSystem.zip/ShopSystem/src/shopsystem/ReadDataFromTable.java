/*  
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package shopsystem;

import java.sql.*;
import java.time.LocalTime;
import java.util.LinkedList;


public class ReadDataFromTable {
       String url = "jdbc:mysql://localhost:3306/ShopSystem";
        String username = "root";
        String password = "Amratku!1";
        String query="";
        public LinkedList readData(int num){
            LinkedList list = new LinkedList();
            if(num == -1)
                 query = "SELECT pid,Vegi_Pizza,Cheese_Pizza,Chicken_Pizza,Tikka_Pizza,Fajita_Pizza,Panner_Pizza,Shuwarma_Pizza,Special_Pizza,total,dates FROM Pizza where dates=curdate()";
            else if (num == -2){
                query = "SELECT bid,Vegi_Burger,Cheese_Burger,Chicken_Burger,Zinger_Burger,Mighty_Zinger,Panner_Burger,Juicy_Zinger,BBQ_Burger,total,dates FROM Burgers where dates=curdate()";
            }
            else if (num == -3){
               query = "SELECT bro_id,Leg_Broast,Chest_Broast,Qty_Chest_Broast,Masala_Broast,Garlic_Broast,Twister_Broast,Chatpatta_Broast,Chatpatta_Stick,total,dates FROM Broast where dates=curdate()"; 
            }
            else if (num == -4){
               query = "SELECT rid,Vegi_Roll,Paneer_Roll,Chicken_Roll,Tikka_Roll,Mayo_Roll,Chatni_Roll,Pizza_Roll,Zinger_Roll,total,dates FROM Rolls where dates=curdate()"; 
            }
            else if (num == -5){
               query = "SELECT did,Mineral_Water,Pepsi,Coca_Cola,Sting,UP_7,Miranda,RedBull,Nestle_Juice,total,dates FROM Drinks where dates=curdate()"; 
            }
            else if (num == -6){
               query = "SELECT ice_id,Vanila,Mango,Blueberry,Chocolate,Coconut,Strawberry,Orieo,CheeseCake,total,dates FROM Icecream where dates=curdate()"; 
            }
            
        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            if(num == -1){
            while (resultSet.next()) {
                list.add(resultSet.getInt("pid"));
                list.add(resultSet.getInt("Vegi_Pizza"));
                list.add(resultSet.getInt("Cheese_Pizza"));
                list.add(resultSet.getInt("Chicken_Pizza"));
                list.add(resultSet.getInt("Tikka_Pizza"));
                list.add(resultSet.getInt("Fajita_Pizza"));
                list.add(resultSet.getInt("Panner_Pizza"));
                list.add(resultSet.getInt("Shuwarma_Pizza"));
                list.add(resultSet.getInt("Special_Pizza"));
                list.add(resultSet.getInt("total"));
                list.add(resultSet.getString("dates"));
            }
            }
            else if (num == -2){
              while (resultSet.next()) {
                list.add(resultSet.getInt("bid"));
                list.add(resultSet.getInt("Vegi_Burger"));
                list.add(resultSet.getInt("Cheese_Burger"));
                list.add(resultSet.getInt("Chicken_Burger"));
                list.add(resultSet.getInt("Zinger_Burger"));
                list.add(resultSet.getInt("Mighty_Zinger"));
                list.add(resultSet.getInt("Panner_Burger"));
                list.add(resultSet.getInt("Juicy_Zinger"));
                list.add(resultSet.getInt("BBQ_Burger"));
                list.add(resultSet.getInt("total"));
                list.add(resultSet.getString("dates"));
            }  
            }
            else if (num == -3){
              while (resultSet.next()) {
                list.add(resultSet.getInt("bro_id"));
                list.add(resultSet.getInt("Leg_Broast"));
                list.add(resultSet.getInt("Chest_Broast"));
                list.add(resultSet.getInt("Qty_Chest_Broast"));
                list.add(resultSet.getInt("Masala_Broast"));
                list.add(resultSet.getInt("Garlic_Broast"));
                list.add(resultSet.getInt("Twister_Broast"));
                list.add(resultSet.getInt("Chatpatta_Broast"));
                list.add(resultSet.getInt("Chatpatta_Stick"));
                list.add(resultSet.getInt("total"));
                list.add(resultSet.getString("dates"));
            }  
            }
            else if (num == -4){
              while (resultSet.next()) {
                list.add(resultSet.getInt("rid"));
                list.add(resultSet.getInt("Vegi_Roll"));
                list.add(resultSet.getInt("Paneer_Roll"));
                list.add(resultSet.getInt("Chicken_Roll"));
                list.add(resultSet.getInt("Tikka_Roll"));
                list.add(resultSet.getInt("Mayo_Roll"));
                list.add(resultSet.getInt("Chatni_Roll"));
                list.add(resultSet.getInt("Pizza_Roll"));
                list.add(resultSet.getInt("Zinger_Roll"));
                list.add(resultSet.getInt("total"));
                list.add(resultSet.getString("dates"));
            }  
            }
            else if (num == -5){
              while (resultSet.next()) {
                list.add(resultSet.getInt("did"));
                list.add(resultSet.getInt("Mineral_Water"));
                list.add(resultSet.getInt("Pepsi"));
                list.add(resultSet.getInt("Coca_Cola"));
                list.add(resultSet.getInt("Sting"));
                list.add(resultSet.getInt("UP_7"));
                list.add(resultSet.getInt("Miranda"));
                list.add(resultSet.getInt("RedBull"));
                list.add(resultSet.getInt("Nestle_Juice"));
                list.add(resultSet.getInt("total"));
                list.add(resultSet.getString("dates"));
            }  
            }
            else if (num == -6){
              while (resultSet.next()) {
                list.add(resultSet.getInt("ice_id"));
                list.add(resultSet.getInt("Vanila"));
                list.add(resultSet.getInt("Mango"));
                list.add(resultSet.getInt("Blueberry"));
                list.add(resultSet.getInt("Chocolate"));
                list.add(resultSet.getInt("Coconut"));
                list.add(resultSet.getInt("Strawberry"));
                list.add(resultSet.getInt("Orieo"));
                list.add(resultSet.getInt("CheeseCake"));
                list.add(resultSet.getInt("total"));
                list.add(resultSet.getString("dates"));
            }  
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
     public int getId(int num){
            int res=0;
            if(num == -1)
                 query = "Select pid from Pizza where dates=DATE_SUB(CURDATE(), INTERVAL 1 DAY);";
            else if (num == -2){
                query = "Select bid from Burgers where dates=DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            }
            else if (num == -3){
               query = "Select bro_id from Broast where dates=DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            }
            else if (num == -4){
               query = "Select rid from Rolls where dates=DATE_SUB(CURDATE(), INTERVAL 1 DAY)"; 
            }
            else if (num == -5){
               query = "Select did from Drinks where dates=DATE_SUB(CURDATE(), INTERVAL 1 DAY)"; 
            }
            else if (num == -6){
               query = "Select ice_id from Icecream where dates=DATE_SUB(CURDATE(), INTERVAL 1 DAY)"; 
            }
            
        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            if(num == -1){
            while (resultSet.next()) {
               res = resultSet.getInt("pid");
              }
            }
            else if (num == -2){
              while (resultSet.next()) {
                res = resultSet.getInt("bid");  
             }  
            }
            else if (num == -3){
              while (resultSet.next()) {
             res = resultSet.getInt("bro_id");
            }  
            }
            else if (num == -4){
              while (resultSet.next()) {
                  res = resultSet.getInt("rid");
            }  
            }
            else if (num == -5){
              while (resultSet.next()) {
                  res = resultSet.getInt("did");
            }  
            }
            else if (num == -6){
              while (resultSet.next()) {
                  res = resultSet.getInt("ice_id");
            }  
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return res;
    }   
        
    public static void main(String[] args) {
//    ReadDataFromTable obj = new ReadDataFromTable();
      LocalTime currentTime = LocalTime.now();
      System.out.println("Time : "+currentTime);
if (currentTime.isAfter(LocalTime.parse("12:10:00"))) {
    // Code to execute if the current time is after 12:10
    System.out.println("AMRAT");
    }
}
}